from brain_games1.prime import game

def main():
    print('Welcome to the Brain Games!')
    game()

if __name__ == '__main__':
    main()
