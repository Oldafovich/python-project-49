# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games1', 'brain_games1.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games1.scripts.brain_calc:main',
                     'brain-even = brain_games1.scripts.brain_even:main',
                     'brain-games = brain_games1.scripts.brain_games:main',
                     'brain-gcd = brain_games1.scripts.brain_gcd:main',
                     'brain-progression = '
                     'brain_games1.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Oldafovich/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Oldafovich/python-project-49/actions)\n<a href="https://codeclimate.com/github/Oldafovich/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/1b159e5aa0dab09e5a98/maintainability" /></a>\n[![Test Coverage](https://api.codeclimate.com/v1/badges/1b159e5aa0dab09e5a98/test_coverage)](https://codeclimate.com/github/Oldafovich/python-project-49/test_coverage)\nhttps://asciinema.org/a/0NIusR52SeVzYio1blW0oDsv0\nhttps://asciinema.org/a/12SLm2qGuw9sOUAe243yaDp7T\nhttps://asciinema.org/a/26eL4ZaATlqbrlaTlJJLTxujI\n',
    'author': 'Даниил Кочнев',
    'author_email': 'oldafovich@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.10,<4.0.0',
}


setup(**setup_kwargs)
