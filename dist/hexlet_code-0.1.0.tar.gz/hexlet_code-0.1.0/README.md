### Hexlet tests and linter status:
[![Actions Status](https://github.com/Oldafovich/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Oldafovich/python-project-49/actions)
<a href="https://codeclimate.com/github/Oldafovich/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/1b159e5aa0dab09e5a98/maintainability" /></a>
[![Test Coverage](https://api.codeclimate.com/v1/badges/1b159e5aa0dab09e5a98/test_coverage)](https://codeclimate.com/github/Oldafovich/python-project-49/test_coverage)
https://asciinema.org/a/0NIusR52SeVzYio1blW0oDsv0
