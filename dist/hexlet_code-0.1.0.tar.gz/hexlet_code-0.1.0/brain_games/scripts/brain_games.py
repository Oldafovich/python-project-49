#!/usr/bin/env python3
if __name__ == '__main__':
        print(f'Welcome to the Brain Games!')

def welcome():
    print(f'Welcome to the Brain Games!')

def main():
    print(f'Welcome to the Brain Games!')

from brain_games.cli import welcome_user
welcome_user()
